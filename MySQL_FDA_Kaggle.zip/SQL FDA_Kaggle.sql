use fda_kaggle;
# Task 1 
select * from RegActionDate where ActionType = "AP" ;

# Task 1 Case 1
 select year(ActionDate) as ActionYear, count("ActionType") from RegActionDate where ActionType IN ("AP") group by ActionYear order by count(ActionType) Desc limit 3;
 
 # Task 1 Case 2 
select year(ActionDate) as ActionYear, count("ActionType") from RegActionDate where ActionType IN ("AP") group by ActionYear order by count(ActionType) Asc limit 3;	


# Task 1 Case 3
select a.SponsorApplicant, year(r.actionDate) from Application AS a INNER JOIN RegActionDate as r on a.ApplNo = r.ApplNo where a.ActionType = "AP";

# Task 1 Case 4
select count(SponsorApplicant),SponsorApplicant from Application where ActionType = "AP" and ApplNo in(select ApplNo from RegActionDate where ActionType = "AP" and Year(ActionDate) Between '1930' and '1969') group by SponsorApplicant;

# Task 2 Case 1
select count(ProductNo), ProductMktStatus from Product group by ProductMktStatus;

# Task 2 Case 2
select count(ApplNo), ProductMktStatus from Product where ApplNo in(select ApplNo from RegActionDate where year(ActionDate) > 2010) group by ProductMktStatus ;

# Task 2 Case 3
select count(p.ApplNo), p.ProductMktStatus, Year(r.ActionDate) from Product as p inner join RegActionDate as r on p.ApplNo = r.ApplNo group by p.ProductMktStatus, p.ApplNo, r.ActionDate;

# Task 3 Case 1
SELECT form, COUNT(*) AS Dosage_form
FROM product
GROUP BY form;

# Task 3 Case 2
Select count(a.ActionType), p.form from product as p inner join application as a on p.ApplNo = a.ApplNo where a.ActionType = "AP" group by a.ActionType, p.form;

# Task 3 Case 3
Select count(a.ActionType), p.form, year(ActionDate) from product as p inner join application as a inner join RegActionDate as rd on p.ApplNo = a.ApplNo and a.ApplNo = rd.ApplNo where a.ActionType = "AP" group by a.ActionType, p.form, year(ActionDate);

# Task 4 Case 1

select count(TECode), TECode from Product_TEcode where ApplNo in(select ApplNo from RegActionDate where ActionType = "AP") group by TECode;

# Task 4 Case 2
select count(pt.TECode), pt.TECode, Year(rd.ActionDate) from Product_TEcode as pt inner join RegActionDate as rd on rd.ApplNo = pt.ApplNo where rd.ActionType = "AP" group by rd.ApplNo, pt.TECode, Year(rd.ActionDate)  order by count(pt.TECode) ;

select count(TECode), TECode from Product_TEcode where ApplNo in(select ApplNo from RegActionDate where ActionType = "AP") group by TECode;